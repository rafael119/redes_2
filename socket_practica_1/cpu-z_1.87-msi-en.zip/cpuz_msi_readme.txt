
CPU-Z MSI Readme file
----------------------

Version 1.87
November 2018
Contact : cpuz@cpuid.com
Web page: https://www.cpuid.com/softwares/cpu-z.html
Validation page : https://valid.x86.fr/
Hall of Fame : https://valid.x86.fr/records.php
CPUID SDK : http://www.cpuid-pro.com/products-services.php


Configuration file (cpuz.ini)
------------------------------

The configuration file must be named cpuz.ini and be present at the same directory level
as cpuz.exe. It contains the following :

[CPU-Z]
VERSION=x.x.x.x
TextFontName=
TextFontSize=14
TextFontColor=000080
LabelFontName=
LabelFontSize=14
ACPI=1
PCI=1
MaxPCIBus=256
DMI=1
Sensor=1
SMBus=1
Display=1
UseDisplayAPI=1
BusClock=1
Chipset=1
SPD=1
XOC=0
CheckUpdates=1


- TextFontName : Font used for the information boxes. 
- TextFontSize : Size of the font used for the information boxes. 
- TextFontColor : Color of the font used for the information boxes. Value is expressed in hexadecimal, and consists in a classic Red/Green/Blue color code : RRGGBB 
- LabelFontName : Font used for the label boxes. 
- LabelFontSize : Size of the font used for the label boxes. 
- Sensor : Set to OFF (or 0) disables sensor chip detection and voltages measurement. 1 to enable.
- PCI : Set to OFF (or 0) disables the PCI information. This disables chipset, SPD and, depending on the hardware, sensoring information. 1 to enable.
- MaxPCIBus : Sets the maximum PCI bus to scan. Default value is 256.
- DMI : Set to OFF (or 0) disables the DMI (Desktop Management Interface) information. This concerns BIOS vendor and version, motherboard vendor and revision. 1 to enable. 
- SMBus : Set to OFF (or 0) disables SMBus information : SPD, and, depending on the hardware, sensoring information. 1 to enable.
- Display : Set to OFF (or 0) disables the video card information reported in the validator. 1 to enable.
- UseDisplayAPI : Set to 1, uses the display driver to read the display adapters information.
- BusClock : Set to 1, uses the bus clock as primary clock source. Set to 0 to use an alternate method.
- Chipset : set to OFF (or 0) disables the memory controller and southbridge information. 1 to enable.
- SPD : set to 0 to disable SPD reading. 1 to enable.
- XOC : eXtreme Overclock Mode : runs CPU-Z with as little system load as possible. Your system won't be fully validated before it is manually checked. Requires to restart CPU-Z.
- CheckUpdates : set to 0 to disable the new version checker at startup. 1 to enable.

Parameters
----------

-txt=filename : Launch CPU-Z in ghost mode (no interface appears) and generates the register dump file (.txt) 
in the same directory as the exe file.

-html=filename : Same as "-txt" except it generates the html report.

-core=id : Displays clock speed of core #id (id can be set from 0 to Number of cores minus one).

-bench : runs CPU-Z without interface, runs the benchmark, and saves the result in a TXT file named like the machine.


Keys
----

F5 : save the current tab in a bmp file
F6 : save the current tab in the clipboard
F7 : save cvf file in the current directory


Cache Latency Tool
------------------

The cache latency tool can be downloaded at that address : http://download.cpuid.com/misc/latency.zip


History
-------

--------------------------------------------------------------------------------------------------
1.87 - November 2018
- Intel Basin Falls Skylake-X refresh.
- NVIDIA GeForce RTX serie 20.
- New AVX2 and AVX512 benchmarks (beta versions).

--------------------------------------------------------------------------------------------------
1.86 - August 2018
- Intel 9th generation Core family (Coffee Lake 9900K, 9700K, 9600K, 9600, 9500 and 9400).
- Intel Coffee Lake-U processors.
- AMD Threadripper 2000 processors.

--------------------------------------------------------------------------------------------------
1.85 - May 2018
- AMD AGESA version report in BIOS information.
- Increased clocks refresh rate.
- Fix initialization error on Windows XP and 7.

--------------------------------------------------------------------------------------------------
1.84 - March 2018
- Intel new Coffee Lake desktop and mobile processors.
- New timers tool.
- New "-bench" parameter.

--------------------------------------------------------------------------------------------------
1.82 - January 2018
- Windows 10 Build 16299 (1.82.2)
- AMD Raven Ridge processors support (1.82.1)
- Intel Xeon Phi Knight Landing preliminary support.
- Fix BCLK fluctuations on SKL-X.
- The benchmark does now support systems with more than 64 CPUs.

--------------------------------------------------------------------------------------------------
1.81.1 - October 2017
- Intel Coffee Lake processors and Z370 platform.
- Intel Skylake-X HCC processors.
- Intel Xeon Skylake-SP and Xeon W Skylake processors.

--------------------------------------------------------------------------------------------------
1.80.1 - August 2017
- Intel Core X processors (KBL-X and SKL-X).
- Preferred core(s) display in clocks dialog.

--------------------------------------------------------------------------------------------------
1.79.1 - May 2017
- Intel X299 (1.79.1).
- AMD ThreadRipper (1.79.1).
- AMD Ryzen 5 and Ryzen 3.
- Fix lockup at loading on Ryzen systems with RAID.
- New benchmark version (17.01).

--------------------------------------------------------------------------------------------------
1.78 - November 2016
- Intel Kaby Lake processors.
- AMD Embedded G and R-series processors.
- DMP Vortex86 DX3.
- Tons of bug fixes.

--------------------------------------------------------------------------------------------------
1.77 - August 2016
- New benchmark "submit and compare" feature.
- New clocks dialog reporting all system's clock speeds in real-time.
- Preliminary support for Intel Kaby Lake.
- AMD Bristol Ridge processors.

--------------------------------------------------------------------------------------------------
1.76 - April 2016
- Intel Broadwell-E/EP processors.
- AVX512 instruction set report.
- Fixed several bugs (missing SPD on some systems).

--------------------------------------------------------------------------------------------------
1.75 - January 2016
- Intel Skylake Pentium and Celeron support.
- Intel Broadwell-E preliminary support.
- AMD A10-7890K APU.

--------------------------------------------------------------------------------------------------
1.74 - October 2015
- Improved CPU benchmark.
- AMD Carrizo APUs.
- eDRAM detection on Slylake CPUs.

--------------------------------------------------------------------------------------------------
1.73 - August 2015
- New validation.
- eXtreme Overclock Mode with light CPU load.
- New tab : CPU Benchmark.
- Added L4 cache frequency (cache tab).
- Added Windows 10 editions.

--------------------------------------------------------------------------------------------------
1.72.1 - June 2015
- Intel Skylake and Broadwell support (1.72.1)
- Preliminary support for Intel Skylake.
- Fixed support for Windows 10 build 9926.
